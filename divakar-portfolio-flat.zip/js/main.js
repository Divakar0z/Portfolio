(function(){
  var root=document.documentElement;
  document.getElementById('yr').textContent=new Date().getFullYear();

  document.getElementById('themeToggle').addEventListener('click',function(){
    var next=root.dataset.theme==='dark'?'light':'dark';
    gsap.fromTo('body',{opacity:.6},{opacity:1,duration:.5});
    root.dataset.theme=next;
    try{localStorage.setItem('theme',next)}catch(e){}
    document.querySelector('meta[name=theme-color]').content=next==='dark'?'#0f0f12':'#f3efe6';
  });

  var skills=['WordPress','React.js','Node.js','PHP','MySQL','MongoDB','Supabase','Tailwind','Burp Suite','C++ DSA'];
  var ring=document.getElementById('ring'),R=300,step=360/skills.length;
  skills.forEach(function(s,i){
    var d=document.createElement('div');d.textContent=s;
    d.style.transform='rotateY('+(i*step)+'deg) translateZ('+R+'px)';
    ring.appendChild(d);
  });

  var h=document.getElementById('heroName'),txt=h.textContent;h.textContent='';
  txt.split('').forEach(function(c){var s=document.createElement('span');s.className='ch';s.textContent=c;s.setAttribute('aria-hidden','true');h.appendChild(s)});

  gsap.registerPlugin(ScrollTrigger);
  var mm=gsap.matchMedia();

  mm.add('(prefers-reduced-motion: no-preference)',function(){
    gsap.from('.ch',{yPercent:110,rotationX:-80,transformOrigin:'50% 100%',opacity:0,duration:1.1,ease:'expo.out',stagger:.06,delay:.1});
    gsap.from('.layer',{z:-200,opacity:0,duration:1.2,ease:'power3.out',stagger:.15,delay:.3});

    var stack=document.getElementById('stack');
    gsap.set(stack,{rotationX:55,rotationZ:-35});
    gsap.to(stack,{y:-14,duration:2.6,yoyo:true,repeat:-1,ease:'sine.inOut'});
    var rx=gsap.quickTo(stack,'rotationX',{duration:.8,ease:'power3'}),rz=gsap.quickTo(stack,'rotationZ',{duration:.8,ease:'power3'});
    window.addEventListener('pointermove',function(e){
      rx(55+(e.clientY/innerHeight-.5)*-20);rz(-35+(e.clientX/innerWidth-.5)*30);
    });
    [['.l2',110],['.l3',220],['.l4',340]].forEach(function(p){
      gsap.to(p[0],{z:p[1],scrollTrigger:{trigger:'.hero',start:'top top',end:'bottom top',scrub:true}});
    });

    gsap.set('.ring-spin',{rotationX:-12});
    gsap.to('.ring',{rotationY:-360,duration:40,repeat:-1,ease:'none'});
    gsap.to('.ring-spin',{rotationY:240,ease:'none',scrollTrigger:{trigger:'.skills',start:'top bottom',end:'bottom top',scrub:1}});

    gsap.set('[data-reveal]',{opacity:0});
    ScrollTrigger.batch('[data-reveal]',{start:'top 88%',once:true,
      onEnter:function(els){gsap.fromTo(els,{y:50,opacity:0},{y:0,opacity:1,duration:.9,ease:'power3.out',stagger:.12})}});

    document.querySelectorAll('.tilt').forEach(function(el){
      var tx=gsap.quickTo(el,'rotationY',{duration:.5,ease:'power2'}),ty=gsap.quickTo(el,'rotationX',{duration:.5,ease:'power2'});
      gsap.set(el,{transformPerspective:900});
      el.addEventListener('pointermove',function(e){
        var b=el.getBoundingClientRect();
        tx(((e.clientX-b.left)/b.width-.5)*10);ty(((e.clientY-b.top)/b.height-.5)*-10);
      });
      el.addEventListener('pointerleave',function(){tx(0);ty(0)});
    });
  });
})();
