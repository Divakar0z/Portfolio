# Divakar — Portfolio
Static site: HTML + CSS + vanilla JS + GSAP (CDN). No build step.

## Structure
index.html · css/style.css · js/main.js · assets/favicon.svg · vercel.json · robots.txt

## Deploy on Vercel
1. Push this folder to a GitHub repo (or run `npx vercel` inside it).
2. Import the repo on vercel.com → Framework Preset: **Other**.
3. Build Command: empty. Output Directory: empty (root). Deploy.

## Edit
Text lives in index.html, colours are CSS variables at the top of css/style.css, skills ring items are in js/main.js.
